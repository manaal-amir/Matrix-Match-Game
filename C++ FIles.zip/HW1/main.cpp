//Syeda Manaal Amir 33550
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
using namespace std;

//func to print mx
void printMatrix(const vector<vector<char>>& matrix) {

    for (int r = 0;r < matrix.size();r++) {
        for (int c = 0;c < matrix[0].size();c++) {
            cout << matrix[r][c];
        }
        cout << endl;
    } cout << endl;
}

//function for gravity
void gravity(vector<vector<char>>& matrix) {
    for (int r = matrix.size() - 2; r >= 0; r--) { // Start from 2nd last row
        for (int c = 0; c < matrix[0].size(); c++) {
            int curRow = r;
            while (curRow < matrix.size() - 1 && matrix[curRow + 1][c] == '-') {
                // Swap current cell with one below if condition met
                char temp = matrix[curRow + 1][c];
                matrix[curRow + 1][c] = matrix[curRow][c];
                matrix[curRow][c] = temp;

                curRow++; // Move downwards
            }
        }
    }
}


//function to clear and display with dash
void dashMx(vector<vector<char>>& matrix) {

    cout << "After clearing matches:" << endl;
    // Horizontal matches
    for (int r = 0; r < matrix.size(); r++) {
        int count = 1;
        for (int c = 1; c < matrix[0].size(); c++) {
            if ((matrix[r][c] == matrix[r][c - 1]) && matrix[r][c] != '-' && matrix[r][c - 1] != '-') {
                count++;
            }
            else {
                if (count >= 3) {
                    for (int k = c - count; k < c; k++) {
                        matrix[r][k] = '-';
                    }
                }
                count = 1;
            }
        }
        if (count >= 3) {
            for (int k = matrix[0].size() - count; k < matrix[0].size(); k++) {
                matrix[r][k] = '-';
            }
        }
    }
    //vertical matches
    for (int c = 0; c < matrix[0].size(); c++) {
        int count = 1;
        for (int r = 1; r < matrix.size(); r++) {
            if ((matrix[r][c] == matrix[r - 1][c]) && matrix[r][c] != '-' && matrix[r - 1][c] != '-') {
                count++;
            }
            else {
                if (count >= 3) {
                    for (int k = r - count; k < r; k++) {
                        matrix[k][c] = '-';
                    }
                }
                count = 1;  
            }
        }
        if (count >= 3) {
            for (int k = matrix.size() - count; k < matrix.size(); k++) {
                matrix[k][c] = '-';
            }
        }
    }

}


    //func to check for match
    bool checkMatch(vector<vector<char>>&matrix) {
        bool Match = false;
        int count;
        //horizontally
        for (int r = 0; r < matrix.size(); r++) {
            count = 1;
            for (int c = 1; c < matrix[0].size(); c++) { //check if matching more than 3 are same characters
                if ((matrix[r][c] == matrix[r][c - 1])&& matrix[r][c]!='-'&& matrix[r][c-1]!='-') {
                    count++;
                    if (count >= 3) {
                        Match = true;
                        break;
                    }
                }
                else {
                    count = 1;
                }
            }
            if (Match) break;
        }
        //vertically
        if (!Match) {
            for (int c = 0; c < matrix[0].size(); c++) {
                count = 1;
                for (int r = 1; r < matrix.size(); r++) {  //check if matching more than 3 are same characters
                    if ((matrix[r][c] == matrix[r - 1][c])&& matrix[r][c]!='-'&& matrix[r-1][c]!='-') {
                        count++;
                        if (count >= 3) {
                            Match = true;
                            break;
                        }
                    }
                    else {
                        count = 1;
                    }
                }
                if (Match) break;
            }
        }return Match;
    }

    //function to validate move and swap
    bool validateMove(int row, int col, vector<vector<char>>&matrix, string direction) {
        //negative inputs
        if (row < 0 || col < 0) {
            cout << "Invalid input. Try again." << endl;
            return false;
        }
        //wrong direction
        if (direction != "u" && direction != "d" && direction != "l" && direction != "r") {
            cout << "Invalid input. Try again." << endl;
            return false;
        }
        //indices out of boundary
        if ( row >= matrix.size() || col >= matrix[0].size()) {
            cout << "Invalid coordinates!" << endl;
            return false;
        }
        // Neighbor out of boundary
        int neighborRow = row;
        int neighborCol = col;
        if (direction == "u") {
            neighborRow = row - 1;
        }
        else if (direction == "d") {
            neighborRow = row + 1;
        }
        else if (direction == "l") {
            neighborCol = col - 1;
        }
        else if (direction == "r") {
            neighborCol = col + 1;
        }
        else {
            cout << "Move out of bounds!" << endl;
            return false;
        }
        if (neighborRow < 0 || neighborRow >= matrix.size() || neighborCol < 0 || neighborCol >= matrix[0].size()) {
            cout << "Move out of bounds!" << endl;
            return false;
        }
        //empty cells
        if (matrix[row][col] == '-' || matrix[neighborRow][neighborCol] == '-') {
            cout << "Cannot swap with an empty cell!" << endl;
            return false;
        }
        //check for swap
        char temp;
        temp = matrix[row][col];
        bool Match;
        matrix[row][col] = matrix[neighborRow][neighborCol];
        matrix[neighborRow][neighborCol] = temp;
        Match = checkMatch(matrix);
        //undo swap
        if (!Match) {
            cout << "Invalid move: No match found!" << endl;
            temp = matrix[row][col];
            matrix[row][col] = matrix[neighborRow][neighborCol];
            matrix[neighborRow][neighborCol] = temp;
            return false;
        }
        else {
            cout << "After swap:\n";
            //printMatrix(matrix);
            return true;
        }



    }

    int main() {
        //checking file validity
        cout << "Please enter the file name: " << endl;
        string nameFile;
        cin >> nameFile;
        ifstream file(nameFile);

        while (file.fail()) {
            cout << "The file couldn't be opened." << endl;
            cout << "Please enter a valid file name: " << endl;
            cin >> nameFile;
            file.clear();
            file.open(nameFile);
        }

        //checking for matrix content
        string line;
        int rowLen = 0;
        int rowCount = 0;
        int rowLength;
        file.seekg(0);
        while (getline(file, line)) {
            if (rowCount == 0) { //if empty file
                rowLength = line.size();
            }
            if (line.size() != rowLength) {  //if dimensions not correct
                cout << "The matrix either has invalid dimensions or contains invalid characters." << endl;
                cout << "Exiting the game. Bye bye.";
                file.close();
                return 0;
            }
            for (char c : line) { //if other characters
                if (c != 'O' && c != 'S' && c != 'X') {
                    cout << "The matrix either has invalid dimensions or contains invalid characters." << endl;
                    cout << "Exiting the game. Bye bye.";
                    file.close();
                    return 0;
                }
                rowCount++;
            }   if (rowCount == 0) {
                cout << "The matrix either has invalid dimensions or contains invalid characters." << endl;
                cout << "Exiting the game. Bye bye.";
                file.close();
                return 0;
            }
        }
        file.close();
        file.open(nameFile);

        //turn into a vector
        vector<vector<char>> matrix;
        string VecLine;
        while (getline(file, VecLine)) {
            vector<char> mxRow;
            for (int i = 0; i < VecLine.length();i++) {
                mxRow.push_back(VecLine.at(i));
            }
            matrix.push_back(mxRow);
        }

        //printing original mx content
        cout << "The content of the matrix is:" << endl;
        printMatrix(matrix);

        //take user input and parse
        cout << "Enter row, col, and direction (r/l/u/d). Type '0 0 q' to exit.\n";
        cout << "Move:\n";
        string move;
        cin.ignore();
        while (getline(cin, move)) {
            if (move == "0 0 q") {
                break;
            }
            stringstream ss(move);
            int row, col;
            string direction;
            ss >> row >> col >> direction;

            //validate the move
            if (validateMove(row, col, matrix, direction)) {
                //swap and display
                printMatrix(matrix);

                //clear and display with dash
                cout << "Move successful. Clearing matches...\n";
                dashMx(matrix);
                printMatrix(matrix);

                //apply gravity and display
                cout << "After applying gravity:" << endl;
                gravity(matrix);
                printMatrix(matrix);

                while (checkMatch(matrix)) {
                    //clear and display with dash
                    dashMx(matrix);
                    printMatrix(matrix);

                    //apply gravity
                    cout << "After applying gravity:" << endl;
                    gravity(matrix);
                    printMatrix(matrix);
                }
            }

                cout << "Move:\n";



        }

        //loop ends, automatic exit
        cout << "Exiting the game. Bye bye.";
        file.close();
        return 0;
    }

